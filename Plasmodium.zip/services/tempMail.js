import axios from 'axios';
import config from 'config';

class TempMailService {
    constructor() {
        this.config = config.api.email;
        this.client = axios.create({
            baseURL: this.config.service,
            timeout: this.config.timeout,
            headers: {
                'Content-Type': 'application/json',
                'X-API-KEY': process.env.EMAILNATOR_API_KEY || 'your-api-key'
            }
        });
        this.emails = new Map();
    }

    async createEmail(username) {
        try {
            // Generate email using emailnator API
            const response = await this.client.post('/email', {
                email: [
                    'custom',
                    'plus.gmail'
                ],
                custom_domain: true,
                custom_username: username
            });

            const email = response.data.email;
            this.emails.set(email, {
                created: Date.now(),
                messages: []
            });

            return email;
        } catch (error) {
            throw new Error(`Failed to create temp email: ${error.message}`);
        }
    }

    async verifyService() {
        try {
            const response = await this.client.get('/status');
            return response.data.status === 'active';
        } catch (error) {
            throw new Error(`Email service verification failed: ${error.message}`);
        }
    }

    async configureInboxMonitoring(email) {
        if (!this.emails.has(email)) {
            throw new Error('Email not found in service');
        }

        try {
            // Start inbox polling
            const pollInterval = setInterval(async () => {
                await this.checkInbox(email);
            }, 5000);

            this.emails.get(email).pollInterval = pollInterval;
            return true;
        } catch (error) {
            throw new Error(`Failed to configure inbox monitoring: ${error.message}`);
        }
    }

    async checkInbox(email) {
        try {
            const response = await this.client.get('/inbox', {
                params: { email }
            });

            const newMessages = response.data.messages;
            const emailData = this.emails.get(email);
            
            // Update stored messages
            emailData.messages = newMessages;
            this.emails.set(email, emailData);

            return newMessages;
        } catch (error) {
            throw new Error(`Failed to check inbox: ${error.message}`);
        }
    }

    async waitForEmail(email, subject, timeout = 60000) {
        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            const checkInterval = setInterval(async () => {
                try {
                    const messages = await this.checkInbox(email);
                    const message = messages.find(m => m.subject.includes(subject));
                    
                    if (message) {
                        clearInterval(checkInterval);
                        resolve(message);
                    }

                    if (Date.now() - startTime > timeout) {
                        clearInterval(checkInterval);
                        reject(new Error('Email wait timeout'));
                    }
                } catch (error) {
                    clearInterval(checkInterval);
                    reject(error);
                }
            }, 5000);
        });
    }

    getServiceDetails() {
        return {
            provider: 'EmailNator',
            status: 'active',
            emailCount: this.emails.size,
            emails: Array.from(this.emails.keys())
        };
    }

    async cleanup() {
        // Clear all polling intervals
        for (const [email, data] of this.emails.entries()) {
            if (data.pollInterval) {
                clearInterval(data.pollInterval);
            }
        }
        this.emails.clear();
    }
}

export { TempMailService }; 