import axios from 'axios';
import config from 'config';

class TempPhoneService {
    constructor() {
        this.client = axios.create({
            baseURL: 'https://api.sms-activate.org/stubs/handler_api.php',
            timeout: 30000,
            params: {
                api_key: process.env.SMS_ACTIVATE_API_KEY || 'your-api-key'
            }
        });
        this.activeNumbers = new Map();
    }

    async getNumber(service = 'ig') {
        try {
            // Get phone number for Instagram
            const response = await this.client.get('/', {
                params: {
                    action: 'getNumber',
                    service: service,
                    country: 7 // Russia (cheaper numbers)
                }
            });

            if (!response.data.startsWith('ACCESS')) {
                throw new Error('Failed to get phone number');
            }

            const [, id, phone] = response.data.split(':');
            this.activeNumbers.set(phone, {
                id: id,
                status: 'waiting',
                created: Date.now()
            });

            return phone;
        } catch (error) {
            throw new Error(`Failed to get phone number: ${error.message}`);
        }
    }

    async waitForSMS(phone, timeout = 120000) {
        if (!this.activeNumbers.has(phone)) {
            throw new Error('Phone number not found');
        }

        return new Promise((resolve, reject) => {
            const startTime = Date.now();
            const checkInterval = setInterval(async () => {
                try {
                    const code = await this.checkSMS(phone);
                    if (code) {
                        clearInterval(checkInterval);
                        resolve(code);
                    }

                    if (Date.now() - startTime > timeout) {
                        clearInterval(checkInterval);
                        await this.cancelNumber(phone);
                        reject(new Error('SMS wait timeout'));
                    }
                } catch (error) {
                    clearInterval(checkInterval);
                    reject(error);
                }
            }, 5000);
        });
    }

    async checkSMS(phone) {
        const number = this.activeNumbers.get(phone);
        try {
            const response = await this.client.get('/', {
                params: {
                    action: 'getStatus',
                    id: number.id
                }
            });

            if (response.data.startsWith('STATUS_OK')) {
                const code = response.data.split(':')[1];
                await this.completeNumber(phone);
                return code;
            }
            return null;
        } catch (error) {
            throw new Error(`Failed to check SMS: ${error.message}`);
        }
    }

    async cancelNumber(phone) {
        const number = this.activeNumbers.get(phone);
        try {
            await this.client.get('/', {
                params: {
                    action: 'setStatus',
                    status: 8, // Cancel activation
                    id: number.id
                }
            });
            this.activeNumbers.delete(phone);
        } catch (error) {
            throw new Error(`Failed to cancel number: ${error.message}`);
        }
    }

    async completeNumber(phone) {
        const number = this.activeNumbers.get(phone);
        try {
            await this.client.get('/', {
                params: {
                    action: 'setStatus',
                    status: 6, // Confirm activation completion
                    id: number.id
                }
            });
            this.activeNumbers.delete(phone);
        } catch (error) {
            throw new Error(`Failed to complete number: ${error.message}`);
        }
    }

    async cleanup() {
        // Cancel all active numbers
        for (const [phone] of this.activeNumbers) {
            await this.cancelNumber(phone).catch(() => {});
        }
        this.activeNumbers.clear();
    }
}

export { TempPhoneService }; 