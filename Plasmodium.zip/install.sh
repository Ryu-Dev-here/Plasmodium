#!/bin/bash

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
NC='\033[0m'

echo -e "${BLUE}Installing Plasmodium Enterprise Manager...${NC}"

# Check OS and install dependencies accordingly
if [ -f /etc/os-release ]; then
    . /etc/os-release
    case $ID in
        "opensuse-tumbleweed")
            echo -e "${GREEN}Detected openSUSE Tumbleweed${NC}"
            sudo zypper refresh
            sudo zypper install -y nodejs npm git python3 make gcc gcc-c++
            ;;
        "ubuntu"|"debian")
            echo -e "${GREEN}Detected Ubuntu/Debian${NC}"
            sudo apt update
            sudo apt install -y nodejs npm git python3 build-essential
            ;;
        "fedora")
            echo -e "${GREEN}Detected Fedora${NC}"
            sudo dnf update
            sudo dnf install -y nodejs npm git python3 make gcc gcc-c++
            ;;
        *)
            echo -e "${RED}Unsupported operating system${NC}"
            exit 1
            ;;
    esac
else
    echo -e "${RED}Could not determine operating system${NC}"
    exit 1
fi

# Install global npm packages
echo -e "${BLUE}Installing global npm packages...${NC}"
sudo npm install -g pm2 node-gyp

# Clone repository
git clone https://github.com/yourusername/plasmodium-enterprise-manager.git
cd plasmodium-enterprise-manager

# Install project dependencies
npm install

# Create necessary directories
mkdir -p logs backups data

# Set permissions
chmod +x index.js

echo -e "${GREEN}Installation complete!${NC}" 