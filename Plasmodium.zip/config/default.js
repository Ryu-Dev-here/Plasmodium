module.exports = {
    theme: {
        primary: '#36FF5A',
        secondary: '#5B8AF7',
        accent: '#FF41C2',
        error: '#FF3636',
        warning: '#FFC107',
        success: '#00E676'
    },
    logging: {
        level: 'info',
        file: 'logs/system.log',
        maxSize: 10485760,
        maxFiles: 10,
        format: 'json',
        compression: true
    },
    monitoring: {
        interval: 500,
        retention: 604800,
        alertThreshold: 90,
        samplingRate: 100,
        autoRecover: true
    },
    security: {
        encryption: 'aes-256-gcm',
        saltRounds: 12,
        jwtSecret: process.env.JWT_SECRET || 'your-secure-jwt-secret',
        tokenExpiry: '24h',
        rateLimiting: {
            windowMs: 900000,
            maxRequests: 100
        }
    },
    api: {
        instagram: {
            baseUrl: 'https://i.instagram.com/api/v1',
            graphUrl: 'https://graph.instagram.com/v12.0',
            timeout: 30000,
            retries: 5,
            endpoints: {
                login: '/accounts/login',
                signup: '/accounts/create',
                media: '/media/configure',
                direct: '/direct_v2/threads/broadcast/text'
            }
        },
        proxy: {
            baseUrl: 'https://proxy.webshare.io/api/v2',
            timeout: 10000,
            retries: 3,
            poolSize: 100
        },
        email: {
            service: 'https://api.emailnator.com/v2',
            timeout: 15000,
            retries: 3
        }
    },
    database: {
        uri: process.env.MONGODB_URI || 'mongodb://localhost:27017/plasmodium',
        options: {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            maxPoolSize: 100,
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000
        }
    },
    redis: {
        host: process.env.REDIS_HOST || 'localhost',
        port: process.env.REDIS_PORT || 6379,
        password: process.env.REDIS_PASSWORD,
        db: 0,
        maxRetriesPerRequest: 3
    },
    system: {
        maxConcurrency: 50,
        maxMemoryUsage: 85,
        maxCpuUsage: 90,
        autoScaling: true,
        cleanupInterval: 3600000,
        backupInterval: 86400000
    },
    notifications: {
        telegram: {
            token: process.env.TELEGRAM_BOT_TOKEN,
            chatId: process.env.TELEGRAM_CHAT_ID
        },
        discord: {
            webhook: process.env.DISCORD_WEBHOOK_URL
        }
    },
    optimization: {
        compression: true,
        caching: true,
        rateLimit: true,
        timeout: 120000,
        keepAlive: true,
        maxPayloadSize: '50mb'
    }
}; 