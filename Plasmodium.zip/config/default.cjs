module.exports = {
    theme: {
        primary: '#36FF5A',
        secondary: '#5B8AF7',
        accent: '#FF41C2',
        error: '#FF3636',
        warning: '#FFC107',
        success: '#00E676'
    },
    // ... rest of the config stays the same
}; 