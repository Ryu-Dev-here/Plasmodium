const chalk = require('chalk');
const gradient = require('gradient-string');

module.exports = {
    colors: {
        primary: chalk.cyan,
        secondary: chalk.magenta,
        success: chalk.green,
        error: chalk.red,
        warning: chalk.yellow,
        info: chalk.blue
    },
    
    gradients: {
        header: gradient(['#FF6B6B', '#4ECDC4']),
        subHeader: gradient(['#45B7D1', '#A6C1EE']),
        highlight: gradient(['#FF61D2', '#FE9090'])
    },

    symbols: {
        success: '✓',
        error: '✗',
        warning: '⚠',
        info: 'ℹ',
        loading: '↻'
    }
}; 