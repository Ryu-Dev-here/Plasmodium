module.exports = {
    API: {
        INSTAGRAM_API_URL: 'https://i.instagram.com/api/v1',
        INSTAGRAM_WEB_URL: 'https://www.instagram.com',
        API_KEY: process.env.INSTAGRAM_API_KEY,
        CLIENT_ID: process.env.INSTAGRAM_CLIENT_ID
    },
    
    HEADERS: {
        'User-Agent': 'Instagram 76.0.0.15.395 Android',
        'Accept-Language': 'en-US',
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'Accept-Encoding': 'gzip, deflate'
    },

    ENDPOINTS: {
        LOGIN: '/accounts/login/',
        SIGNUP: '/accounts/create/',
        VERIFY_EMAIL: '/accounts/send_verify_email/',
        VERIFY_SMS: '/accounts/verify_sms_code/',
        SYNC: '/qe/sync/'
    },

    ERROR_CODES: {
        RATE_LIMITED: 429,
        BAD_REQUEST: 400,
        UNAUTHORIZED: 401,
        FORBIDDEN: 403
    },

    TIMEOUTS: {
        REQUEST: 30000,
        RETRY: 5000,
        COOLDOWN: 300000
    }
}; 