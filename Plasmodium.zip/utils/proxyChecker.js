import axios from 'axios';

class ProxyChecker {
    constructor(config) {
        this.config = config;
    }

    async checkProxy(proxy) {
        try {
            const response = await axios.get('https://api.ipify.org?format=json', {
                proxy: {
                    host: proxy.host,
                    port: proxy.port,
                    auth: proxy.auth
                },
                timeout: 10000
            });
            return { valid: true, ip: response.data.ip };
        } catch (error) {
            return { valid: false, error: error.message };
        }
    }

    async validateProxyList(proxyList) {
        const results = [];
        for (const proxy of proxyList) {
            const result = await this.checkProxy(proxy);
            results.push({ proxy, ...result });
        }
        return results;
    }
}

export default ProxyChecker; 