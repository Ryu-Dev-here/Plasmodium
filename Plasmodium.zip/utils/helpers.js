import crypto from 'crypto';
import UserAgent from 'user-agents';

export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const randomUserAgent = () => new UserAgent().toString();

export const generateUsername = (length = 12) => {
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789_';
    return Array.from(crypto.randomBytes(length))
        .map(byte => chars[byte % chars.length])
        .join('');
};

export const generatePassword = () => {
    const length = 12;
    const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*';
    return Array.from(crypto.randomBytes(length))
        .map(byte => charset[byte % charset.length])
        .join('');
};

export const formatDate = (date) => {
    return new Date(date).toISOString();
};

export const generateDeviceId = () => {
    return crypto.randomBytes(8).toString('hex');
};

export const shuffleArray = (array) => {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}; 