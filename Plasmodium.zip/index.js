import { PlasmodiumEnterpriseManager } from './InstagramBot.js';
import config from 'config';
import chalk from 'chalk';

async function main() {
    const manager = new PlasmodiumEnterpriseManager();

    try {
        // Initialize and display welcome screen
        await manager.displayEnhancedWelcome();
        
        // Initialize core services
        await manager.initializeEnterpriseServices();

        // Show interactive dashboard
        await manager.showDashboard();

        // Start monitoring system resources
        await manager.monitorSystemResources();

    } catch (error) {
        await manager.handleCriticalError(error);
        process.exit(1);
    } finally {
        await manager.cleanup();
    }
}

// Update this to use ESM style
if (import.meta.url === `file://${process.argv[1]}`) {
    main().catch(async error => {
        console.error(chalk.red('\n❌ Critical Error:', error.message));
        process.exit(1);
    });
}